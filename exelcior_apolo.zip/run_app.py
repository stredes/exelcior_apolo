from app.main_app import main

if __name__ == "__main__":
    main()
